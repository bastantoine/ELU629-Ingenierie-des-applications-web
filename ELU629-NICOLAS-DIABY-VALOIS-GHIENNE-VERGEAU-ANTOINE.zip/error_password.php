<?php

// Auteurs : Bastien & Pierre-Adrien

session_start();

?>
<!doctype html>
<html lang="fr">
<head>
	<?php include("includes/header.php"); ?>
	<title>Erreur</title>
</head>
<body>
	<?php include("includes/navigation.php"); ?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h3>Erreur</h3>
				<p>Le mot de passe utilisée n'est pas valide<br/>Veuillez réessayer</p>
			</div>
		</div>
	</div>
</body>
</html>