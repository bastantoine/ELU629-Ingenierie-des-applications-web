Installer et configurer le site

1. Décompresser l'archive

2. Envoyer les fichier sur un serveur FTP

3. Initialiser les tables dans une base de données en utilisant le fichier `baseDeDonnees.sql`

4. Créer un fichier `config.ini` dans le dossier `includes`.
   Dans ce fichier, renseigner ces 4 lignes :
   server       :       le lien d'accès au serveur où est stockée la base de données
   database     :       le nom de la base de données utilisée
   login        :       le login utilisé pour accéder à la base de données
   password     :       le mot de passe du login

Plusieurs utilisateurs ont été créés dans le fichier fournis :
- admin
    email : admin@admin.fr
    mdp : admin
    catégorie : admin
- bastien
    email : bastien@antoine.fr
    mdp : bastien
    catégorie : contributeur
- paul
    email : paul@valois.fr
    mdp : paul
    catégorie : commentateur
- corentine
    email : corentine@nicolas.fr
    mdp : corentine
    catégorie : utilisateur